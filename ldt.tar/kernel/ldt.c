/*
 * linux/kernel/ldt.c
 * Copyright (C) 1992 Krishna Balasubramanian
 */

#include <linux/config.h>
#include <linux/errno.h>
#include <linux/sched.h>
#include <asm/segment.h>
#include <linux/ldt.h>

extern int sys_modify_ldt(int func, void *ptr)
{
    struct modify_ldt_ldt_s ldt_info;
    unsigned long *lp;
    int error;

    switch (func)
    {
      case 0:
	error = verify_area(VERIFY_WRITE, ptr, sizeof(current->ldt));
	if (error)
	    return error;
	
	memcpy_tofs(ptr, current->ldt, sizeof(current->ldt));
	return 0;

      case 1:
	error = verify_area(VERIFY_READ, ptr, sizeof(ldt_info));
	if (error)
	    return error;
	
	memcpy_fromfs(&ldt_info, ptr, sizeof(ldt_info));
	if (ldt_info.contents == 3 || ldt_info.entry_number >= 32)
	    return -EINVAL;

	if (ldt_info.limit_in_pages)
	{
	    if (ldt_info.base_addr + (ldt_info.limit * 4096) >= 0xC0000000)
		return -EINVAL;
	}
	else
	{
	    if (ldt_info.base_addr + ldt_info.limit >= 0xC0000000)
		return -EINVAL;
	}
	
	lp = (unsigned long *) &current->ldt[ldt_info.entry_number];
       	*lp = ((ldt_info.base_addr & 0x0000ffff) << 16) |
	      (ldt_info.limit & 0x0ffff);
	*(lp+1) = (ldt_info.base_addr & 0xff000000) |
	          ((ldt_info.base_addr & 0x00ff0000)>>16) |
		  (ldt_info.limit & 0xf0000) |
		  (ldt_info.contents << 10) |
		  ((ldt_info.read_exec_only ^ 1) << 9) |
		  (ldt_info.seg_32bit << 22) |
		  (ldt_info.limit_in_pages << 23) |
       	          0xf000;
	return 0;
    }
    
    return -ENOSYS;
}
